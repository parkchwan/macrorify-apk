# Macrorify + Tasker Pro 안드로이드 APK 빌드 및 설치 가이드

이 패키지는 **Macrorify의 모든 자동 클릭/이미지 감지/EMScript 인터페이스**와 **테스커(Tasker)의 시작 시간(From/To/Every)·특정시간 대기(Wait Until)·특정 날짜·특정 요일 스케줄러**를 완벽히 통합한 안드로이드 네이티브 프로젝트입니다.

---

## 방법 1. Android Studio에서 즉시 `.apk` 파일 추출하기 (권장)
1. 본 압축 파일(`Macrorify_Tasker_Android_APK_Project.zip`)의 압축을 풉니다.
2. **Android Studio**를 실행하고 **Open**을 눌러 압축을 푼 폴더를 엽니다.
3. 상단 메뉴에서 **Build > Build Bundle(s) / APK(s) > Build APK(s)** 를 클릭합니다.
4. 약 1분 후 생성된 `app-debug.apk` (또는 `app-release.apk`) 파일을 스마트폰으로 전송하여 설치합니다.
5. 설치 후 **설정 > 접근성 > 설치된 앱 > Macrorify + Tasker Auto Clicker** 권한과 **다른 앱 위에 표시** 권한을 켜면 실제 기기 전역에서 작동합니다.

## 방법 2. PC에 프로그램 설치 없이 GitHub Actions로 무료 클라우드 APK 빌드하기
1. 본 폴더를 본인의 GitHub 저장소(Repository)에 업로드합니다.
2. 이미 포함된 `.github/workflows/build-apk.yml` 워크플로우가 자동으로 실행되어 클라우드에서 `.apk`를 컴파일합니다.
3. GitHub 저장소의 **Actions** 탭 → 완료된 워크플로우 하단 **Artifacts (`Macrorify-Tasker-Pro-APK`)**를 클릭해 완성된 `.apk` 파일을 스마트폰에 바로 다운로드 및 설치할 수 있습니다.
