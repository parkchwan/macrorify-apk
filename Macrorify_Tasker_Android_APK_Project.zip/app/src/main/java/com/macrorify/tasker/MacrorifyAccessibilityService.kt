package com.macrorify.tasker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

class MacrorifyAccessibilityService : AccessibilityService() {

    companion object {
        var instance: MacrorifyAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // React to window state changes or OCR text nodes if needed
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /**
     * Executes a single or multi-finger tap using Android's GestureDescription API.
     */
    fun dispatchTap(x: Float, y: Float, durationMs: Long = 80L) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(10L))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    /**
     * Executes a swipe gesture from (x1, y1) to (x2, y2).
     */
    fun dispatchSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 350L) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(50L))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    /**
     * Tasker 'Wait Until' (특정시간까지 대기) implementation in native loop:
     * Waits until target HH:mm:ss, optional YYYY-MM-DD date, and optional DayOfWeek match,
     * then invokes onReached().
     */
    fun waitUntilTime(
        targetHms: String,
        targetDateYmd: String?,
        targetDayOfWeek: Int?, // 0=Sun..6=Sat or null
        onReached: () -> Unit
    ) {
        val formatter = DateTimeFormatter.ofPattern("HH:mm:ss")
        val targetLocalTime = LocalTime.parse(targetHms, formatter)

        val checkRunnable = object : Runnable {
            override fun run() {
                val nowDate = LocalDate.now()
                val nowTime = LocalTime.now()
                val dateOk = targetDateYmd.isNullOrEmpty() || nowDate.toString() == targetDateYmd
                val dowZeroBased = nowDate.dayOfWeek.value % 7 // Sun=0..Sat=6
                val dayOk = targetDayOfWeek == null || dowZeroBased == targetDayOfWeek

                if (dateOk && dayOk && !nowTime.isBefore(targetLocalTime)) {
                    onReached()
                } else {
                    handler.postDelayed(this, 250L)
                }
            }
        }
        handler.post(checkRunnable)
    }
}
