package com.macrorify.tasker

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
        }
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidNativeBridge(), "AndroidNative")

        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class AndroidNativeBridge {

        @JavascriptInterface
        fun openAccessibilitySettings() {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        @JavascriptInterface
        fun requestOverlayPermission() {
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
        }

        @JavascriptInterface
        fun performNativeClick(x: Float, y: Float, durationMs: Long) {
            MacrorifyAccessibilityService.instance?.dispatchTap(x, y, durationMs)
        }

        @JavascriptInterface
        fun performNativeSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
            MacrorifyAccessibilityService.instance?.dispatchSwipe(x1, y1, x2, y2, durationMs)
        }

        @JavascriptInterface
        fun scheduleTaskerAlarm(
            fromTimeHms: String,
            toTimeHms: String,
            daysCsv: String,
            datesCsv: String,
            everyMinutes: Int
        ) {
            TaskerAlarmScheduler.scheduleNextTrigger(
                this@MainActivity,
                fromTimeHms,
                toTimeHms,
                daysCsv,
                datesCsv,
                everyMinutes
            )
            runOnUiThread {
                Toast.makeText(
                    this@MainActivity,
                    "테스커 알람 예약 완료: $fromTimeHms (요일: $daysCsv)",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}
