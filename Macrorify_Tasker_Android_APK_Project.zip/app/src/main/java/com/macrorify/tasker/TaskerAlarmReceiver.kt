package com.macrorify.tasker

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

class TaskerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            "com.macrorify.tasker.ACTION_START_MACRO" -> {
                // Trigger default macro sequence at the scheduled Tasker start time
                MacrorifyAccessibilityService.instance?.dispatchTap(340f, 195f, 80L)
            }
            "com.macrorify.tasker.ACTION_STOP_MACRO" -> {
                // Stop active macro when Tasker To-Time is reached
            }
        }
    }
}

object TaskerAlarmScheduler {
    fun scheduleNextTrigger(
        context: Context,
        fromTimeHms: String,
        toTimeHms: String,
        daysCsv: String,
        datesCsv: String,
        everyMinutes: Int
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val parts = fromTimeHms.split(":").map { it.toIntOrNull() ?: 0 }
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, parts.getOrElse(0) { 9 })
            set(Calendar.MINUTE, parts.getOrElse(1) { 0 })
            set(Calendar.SECOND, parts.getOrElse(2) { 0 })
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        val intent = Intent(context, TaskerAlarmReceiver::class.java).apply {
            action = "com.macrorify.tasker.ACTION_START_MACRO"
            putExtra("TO_TIME", toTimeHms)
            putExtra("DAYS_CSV", daysCsv)
            putExtra("DATES_CSV", datesCsv)
            putExtra("EVERY_MIN", everyMinutes)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            1001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        alarmManager.setExactAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            cal.timeInMillis,
            pendingIntent
        )
    }
}
